package com.example.soundboard;

import static android.media.MediaPlayer.*;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.Random;

public class MainActivity extends AppCompatActivity {


    int[] sounds={R.raw.sound, R.raw.sound2, R.raw.sound3, R.raw.sound4, R.raw.sound5, R.raw.sound6};
    Random r = new Random();
    int Low = 0;
    int High = 10;
    int rndm = r.nextInt(High-Low) + Low;



    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button one = (Button) this.findViewById(R.id.button);
        final MediaPlayer boom = create(this, R.raw.sound);
        one.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (boom.isPlaying()){
                    boom.seekTo(0);
                    }
                    else
                        boom.start();
            }
        });

        Button two = (Button) this.findViewById(R.id.button2);
        final MediaPlayer fart = create(this, R.raw.sound2);
        two.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (fart.isPlaying()){
                    fart.seekTo(0);
                    }
                    else
                        fart.start();
            }
        });

        Button three = (Button) this.findViewById(R.id.button3);
        final MediaPlayer whattdd = create(this, R.raw.sound3);
        three.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (whattdd.isPlaying()) {
                    whattdd.seekTo(0);
                }

                else
                    whattdd.start();
            }
        });


        Button four = (Button) this.findViewById(R.id.button4);
        final MediaPlayer amongus1 = create(this, R.raw.sound4);
        four.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (amongus1.isPlaying()) {
                    amongus1.seekTo(0);
                }

                else
                    amongus1.start();
            }
        });

        Button five = (Button) this.findViewById(R.id.button5);
        final MediaPlayer amongus2 = create(this, R.raw.sound5);
        five.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (amongus2.isPlaying()) {
                    amongus2.seekTo(0);
                }

                else
                    amongus2.start();
            }
        });

        Button six = (Button) this.findViewById(R.id.button6);
        final MediaPlayer bruh = create(this, R.raw.sound6);
        six.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (bruh.isPlaying()) {
                    bruh.seekTo(0);
                }

                else
                    bruh.start();
            }
        });

        Button seven = (Button) this.findViewById(R.id.button7);
        final MediaPlayer soundSev = MediaPlayer.create(this, R.raw.sound7);
        seven.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (soundSev.isPlaying()) {
                    soundSev.seekTo(0);
                }

                else
                    soundSev.start();
            }
        });

        Button eight = (Button) this.findViewById(R.id.button8);
        final MediaPlayer soundEig = MediaPlayer.create(this, R.raw.sound8);
        eight.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (soundEig.isPlaying()) {
                    soundEig.seekTo(0);
                }

                else
                    soundEig.start();
            }
        });

        Button nine = (Button) this.findViewById(R.id.button9);
        final MediaPlayer soundNine = MediaPlayer.create(this, R.raw.sound9);
        nine.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (soundNine.isPlaying()) {
                    soundNine.seekTo(0);
                }

                else
                    soundNine.start();
            }
        });

        Button ten = (Button) this.findViewById(R.id.button10);
        final MediaPlayer soundTen = MediaPlayer.create(this, R.raw.sound10);
        ten.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (soundTen.isPlaying()) {
                    soundTen.seekTo(0);
                }

                else
                    soundTen.start();
            }
        });

        Button eleven = (Button) this.findViewById(R.id.button11);
        final MediaPlayer soundEle = MediaPlayer.create(this, R.raw.sound11);
        eleven.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (soundEle.isPlaying()) {
                    soundEle.seekTo(0);
                }

                else
                    soundEle.start();
            }
        });

        Button twelve = (Button) this.findViewById(R.id.button12);
        final MediaPlayer soundTwe = MediaPlayer.create(this, R.raw.sound12);
        twelve.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (soundTwe.isPlaying()) {
                    soundTwe.seekTo(0);
                }

                else
                    soundTwe.start();
            }
        });

//special
        Button beeButton = (Button) this.findViewById(R.id.beeButton);
        final MediaPlayer bee = create(this, R.raw.bee);
        beeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                if (bee.isPlaying()) {
                    bee.seekTo(0);
                }

                else
                    bee.start();
            }
        });

//        Button randomButton = (Button)this.findViewById(R.id.randomButton);
//        final MediaPlayer[][] mp = {{create(getApplicationContext(), sounds[rndm])}};
//        randomButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (mp[0].isPlaying()) {
//                    mp[0].stop();
//                    mp[0].release();
//                    rndm = r.nextInt(High-Low) + Low;
//                    mp[0] = create(getApplicationContext(),sounds[rndm]);
//                }
//                mp[0].start();
//
//            }
//        });

    }
}